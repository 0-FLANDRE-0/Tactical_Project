#!/usr/bin/env python3
"""Build an offline, single-file HTML. Python standard library only."""
from pathlib import Path
root=Path(__file__).resolve().parent
page=(root/'src/page.html').read_text(encoding='utf-8')
for token,name in [('STYLES','styles.css'),('SIM_CORE','sim-core.js'),('APP_CODE','app.js')]:
    marker='{{'+token+'}}'
    if page.count(marker)!=1:
        raise ValueError('Expected exactly one '+marker)
    page=page.replace(marker,(root/'src'/name).read_text(encoding='utf-8'))
(root/'dist').mkdir(exist_ok=True)
(root/'dist/index.html').write_text(page,encoding='utf-8')
print('Built dist/index.html')
