// Run with node tests/core.test.cjs. Extract the shipped core, never a stale copy.
const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const html=fs.readFileSync(require('path').join(__dirname,'../dist/index.html'),'utf8');
const script=html.match(/<script id="sim-core">([\s\S]*?)<\/script>/)[1];
const context={module:{exports:{}},Float32Array,Float64Array,Int32Array,Uint8Array,Math};
vm.runInNewContext(script,context);const C=context.module.exports;let passed=0;
function test(name,fn){fn();passed++;console.log('PASS '+name)}
test('all spawn positions accept vehicle footprint',()=>{const s=C.createScenario();for(const u of s.units)assert(C.passable(u.x,u.y,s.units,u),u.id)});
test('height field is finite and continuous',()=>{for(let y=0;y<=1250;y+=29)for(let x=0;x<=1800;x+=31){assert(Number.isFinite(C.heightAt(x,y)));assert(Math.abs(C.heightAt(x+.01,y)-C.heightAt(x,y))<.02)}});
test('river blocks movement, bridges accept vehicle footprint',()=>{assert(!C.passable(C.riverX(700),700));assert(C.passable(C.riverX(940),940));assert(C.passable(C.riverX(410),410))});
test('building and map edge destinations reject movement',()=>{const s=C.createScenario(),u=s.units[0];for(const p of [{x:1280,y:275},{x:-2,y:500},{x:C.riverX(700),y:700}])assert(!C.planPath(u,p,s.units,u).ok)});
test('route crosses river only on a bridge and every segment is passable',()=>{const s=C.createScenario(),u=s.units[0],r=C.planPath(u,{x:1400,y:940},s.units,u);assert(r.ok);let a=u,crossed=false;for(const b of r.points){assert(C.segmentClear(a,b,s.units,u));for(let t=0;t<=1;t+=.01){const x=C.mix(a.x,b.x,t),y=C.mix(a.y,b.y,t);if(Math.abs(x-C.riverX(y))<15){assert(C.bridgeAt(x,y));crossed=true}}a=b}assert(crossed)});
test('four long routes arrive without terrain or unit penetration',()=>{for(const goal of [{x:650,y:780},{x:1400,y:940},{x:950,y:410},{x:1550,y:700}]){const s=C.createScenario(),u=s.units[0];assert(C.issueMove(u,goal,false,s.units).ok);let n=0;for(;n<8000&&u.path.length;n++){C.step(s,.05);assert(C.passable(u.x,u.y,s.units,u))}assert(n<8000);assert(Math.hypot(u.x-goal.x,u.y-goal.y)<3);assert.equal(u.speed,0)}});
test('reverse preserves hull orientation for a rearward goal',()=>{const s=C.createScenario(),u=s.units[0],h=u.heading,g={x:u.x-Math.cos(h)*45,y:u.y-Math.sin(h)*45};assert(C.issueMove(u,g,true,s.units).ok);for(let i=0;i<2000&&u.path.length;i++)C.step(s,.05);assert(Math.hypot(u.x-g.x,u.y-g.y)<3);assert(Math.abs(C.angleDiff(u.heading,h))<.1)});
test('stop cancels path and brakes within bounded time',()=>{const s=C.createScenario(),u=s.units[0];C.issueMove(u,{x:650,y:780},false,s.units);for(let i=0;i<100;i++)C.step(s,.05);assert(u.speed>0);C.stop(u);for(let i=0;i<120;i++)C.step(s,.05);assert.equal(u.speed,0);assert.equal(u.path.length,0);assert.equal(u.goal,null)});
test('fixed simulation step is independent of render batch sizes',()=>{const a=C.createScenario(),b=C.createScenario();for(const s of [a,b])C.issueMove(s.units[0],{x:1400,y:940},false,s.units);for(let i=0;i<1200;i++)C.step(a,.05);for(let frame=0;frame<300;frame++)for(let i=0;i<4;i++)C.step(b,.05);assert.equal(JSON.stringify(a),JSON.stringify(b))});
test('observation limits range and opaque structures',()=>{assert.equal(C.lineOfSight({x:100,y:100},{x:1500,y:100}).reason,'range');assert(!C.lineOfSight({x:1250,y:275},{x:1320,y:275},1.5).visible)});
test('forest optical depth can block a geometrically unobstructed ray',()=>{let found=false;for(let y=300;y<=500;y+=40)for(let x=250;x<=450;x+=30)if(C.lineOfSight({x,y},{x:x+180,y},1.5).reason==='forest')found=true;assert(found)});
test('hull and turret exposure vary independently at a ridge',()=>{const e=C.exposure({x:500,y:800},{x:795,y:650,heading:0});assert(e.visible);assert(e.turret>e.hull);assert(e.hull>0&&e.hull<1)});
console.log(JSON.stringify({passed,failed:0,version:'0.4-WIP01'}));
