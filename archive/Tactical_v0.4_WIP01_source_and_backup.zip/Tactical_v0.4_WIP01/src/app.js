(() => {
  const C=TacticalCore,$=id=>document.getElementById(id),canvas=$('map'),ctx=canvas.getContext('2d'),wrap=$('mapWrap');
  let sim=C.createScenario(),selected='A11',targetId=null,paused=false,timeScale=1,reverseMode=false,showContours=true,sightHeld=false,sightPointer=null,sightKey=false,last=performance.now(),accumulator=0,uiTime=0,toastUntil=0,visibilityDirty=true,visLast=-1,visOrigin=null,frameCount=0;
  const camera={
    x:900,y:625,zoom:.5,w:1,h:1,dpr:1
  }
  ,trails=[],pointers=new Map();
  let gesture=null,dragged=false,clickStart=null;
  const selectedUnit=()=>sim.units.find(u=>u.id===selected);
  const terrainCanvas=document.createElement('canvas'),contourCanvas=document.createElement('canvas'),visCanvas=document.createElement('canvas');
  const MAP_SCALE=1.1;
  terrainCanvas.width=contourCanvas.width=C.WORLD.w*MAP_SCALE;
  terrainCanvas.height=contourCanvas.height=C.WORLD.h*MAP_SCALE;
  function poly(g,pts,close=false){
    g.beginPath();
    pts.forEach((p,i)=>i?g.lineTo(p.x,p.y):g.moveTo(p.x,p.y));
    if(close)g.closePath()
  }
  function renderTerrain(){
    const g=terrainCanvas.getContext('2d'),w=terrainCanvas.width,h=terrainCanvas.height,img=g.createImageData(w,h);
    for(let y=0;
    y<h;
    y++)for(let x=0;
    x<w;
    x++){
      const wx=x/MAP_SCALE,wy=y/MAP_SCALE,z=C.heightAt(wx,wy),dx=C.heightAt(wx+4,wy)-C.heightAt(wx-4,wy),dy=C.heightAt(wx,wy+4)-C.heightAt(wx,wy-4),shade=C.clamp(-dx*.065-dy*.09,-.24,.24),grain=(C.hash(x,y)-.5)*7,k=(y*w+x)*4;
      img.data[k]=151+z*.12+shade*100+grain;
      img.data[k+1]=158+z*.11+shade*100+grain;
      img.data[k+2]=115+z*.08+shade*82+grain;
      img.data[k+3]=255
    }
    g.putImageData(img,0,0);
    g.save();
    g.scale(MAP_SCALE,MAP_SCALE);
    // Subtle fields, terrain features and bank geometry all use world metres.
    for(const f of [{
      x:130,y:780,w:155,h:110
    }
    ,{
      x:80,y:590,w:160,h:105
    }
    ,{
      x:1210,y:1000,w:120,h:100
    }
    ,{
      x:1510,y:450,w:155,h:100
    }
    ,{
      x:1200,y:520,w:120,h:130
    }
    ]){
      g.fillStyle='#b5b17c32';
      g.fillRect(f.x,f.y,f.w,f.h);
      g.strokeStyle='#697e4e32';
      g.lineWidth=1;
      for(let y=f.y;
      y<f.y+f.h;
      y+=10){
        g.beginPath();
        g.moveTo(f.x,y);
        g.lineTo(f.x+f.w,y);
        g.stroke()
      }
    }
    let river=[];
    for(let y=-20;
    y<=1270;
    y+=8)river.push({
      x:C.riverX(y),y
    }
    );
    poly(g,river);
    g.strokeStyle='#657d6970';
    g.lineWidth=55;
    g.stroke();
    poly(g,river);
    g.strokeStyle='#688a83';
    g.lineWidth=39;
    g.stroke();
    poly(g,river);
    g.strokeStyle='#90aea0';
    g.lineWidth=26;
    g.stroke();
    poly(g,river);
    g.strokeStyle='#bfd0b03f';
    g.lineWidth=1.5;
    g.stroke();
    for(const road of C.roads){
      poly(g,road);
      g.lineCap='round';
      g.lineJoin='round';
      g.strokeStyle='#64725670';
      g.lineWidth=27;
      g.stroke();
      poly(g,road);
      g.strokeStyle='#b6b397';
      g.lineWidth=20;
      g.stroke();
      poly(g,road);
      g.strokeStyle='#d3c9a657';
      g.lineWidth=2;
      g.setLineDash([8,10]);
      g.stroke();
      g.setLineDash([])
    }
    for(const y of [410,940]){
      const x=C.riverX(y);
      g.fillStyle='#797f6a';
      g.fillRect(x-44,y-15,88,30);
      g.strokeStyle='#d0cbb3';
      g.lineWidth=2;
      for(const yy of [y-16,y+16]){
        g.beginPath();
        g.moveTo(x-45,yy);
        g.lineTo(x+45,yy);
        g.stroke()
      }
      g.strokeStyle='#515e4d';
      g.lineWidth=1;
      for(let xx=x-39;
      xx<x+44;
      xx+=10){
        g.beginPath();
        g.moveTo(xx,y-12);
        g.lineTo(xx,y+12);
        g.stroke()
      }
    }
    for(let y=20;
    y<C.WORLD.h;
    y+=14)for(let x=20;
    x<C.WORLD.w;
    x+=14){
      const xx=x+(C.hash(x,y,13)-.5)*15,yy=y+(C.hash(x,y,91)-.5)*15,f=C.forestAt(xx,yy);
      if(f<.12||C.hash(x,y,42)>f*.88||C.roadDistance(xx,yy)<17||C.waterAt(xx,yy)||C.solidAt(xx,yy))continue;
      const r=5+C.hash(x,y,9)*7;
      g.fillStyle='#28433330';
      g.beginPath();
      g.ellipse(xx+3,yy+5,r+2,r*.8,0,0,Math.PI*2);
      g.fill();
      g.fillStyle=['#4e6947','#5a744b','#688052','#526d46'][Math.floor(C.hash(x,y,4)*4)];
      g.beginPath();
      g.arc(xx,yy,r,0,Math.PI*2);
      g.fill();
      g.fillStyle='#8b9c5a28';
      g.beginPath();
      g.arc(xx-2,yy-2,r*.65,0,Math.PI*2);
      g.fill()
    }
    for(const r of C.rocks){
      g.fillStyle='#43524540';
      g.beginPath();
      g.ellipse(r.x+5,r.y+6,r.r*1.1,r.r*.8,0,0,Math.PI*2);
      g.fill();
      g.fillStyle='#8b927f';
      poly(g,[{
        x:r.x-r.r,y:r.y
      }
      ,{
        x:r.x-r.r*.4,y:r.y-r.r*.9
      }
      ,{
        x:r.x+r.r*.7,y:r.y-r.r*.65
      }
      ,{
        x:r.x+r.r,y:r.y+r.r*.3
      }
      ,{
        x:r.x,y:r.y+r.r*.85
      }
      ],true);
      g.fill();
      g.strokeStyle='#6b7865';
      g.lineWidth=2;
      g.stroke();
      g.strokeStyle='#bdc0a2';
      g.beginPath();
      g.moveTo(r.x-r.r*.4,r.y-r.r*.8);
      g.lineTo(r.x+r.r*.6,r.y-r.r*.6);
      g.stroke()
    }
    for(const b of C.buildings){
      g.fillStyle='#24382945';
      g.fillRect(b.x+5,b.y+7,b.w,b.h);
      g.fillStyle='#8b8876';
      g.fillRect(b.x,b.y,b.w,b.h);
      g.strokeStyle='#626c58';
      g.lineWidth=2;
      g.strokeRect(b.x,b.y,b.w,b.h);
      g.strokeStyle='#bdb69b';
      g.beginPath();
      g.moveTo(b.x+3,b.y+b.h*.5);
      g.lineTo(b.x+b.w-3,b.y+b.h*.5);
      g.stroke()
    }
    g.restore();
    const cg=contourCanvas.getContext('2d');
    cg.scale(MAP_SCALE,MAP_SCALE);
    for(let level=20;
    level<=130;
    level+=10){
      cg.beginPath();
      const step=10;
      for(let y=0;
      y<1250;
      y+=step)for(let x=0;
      x<1800;
      x+=step){
        const pts=[{
          x,y
        }
        ,{
          x:x+step,y
        }
        ,{
          x:x+step,y:y+step
        }
        ,{
          x,y:y+step
        }
        ],zs=pts.map(p=>C.heightAt(p.x,p.y)),cuts=[];
        for(let i=0;
        i<4;
        i++){
          const j=(i+1)%4;
          if((zs[i]<level)!==(zs[j]<level)){
            const t=(level-zs[i])/(zs[j]-zs[i]);
            cuts.push({
              x:C.mix(pts[i].x,pts[j].x,t),y:C.mix(pts[i].y,pts[j].y,t)
            }
            )
          }
        }
        for(let i=0;
        i+1<cuts.length;
        i+=2){
          cg.moveTo(cuts[i].x,cuts[i].y);
          cg.lineTo(cuts[i+1].x,cuts[i+1].y)
        }
      }
      cg.strokeStyle=level%50===0?'#384d37a0':'#4b624e59';
      cg.lineWidth=level%50===0?1.5:.75;
      cg.stroke()
    }
    cg.font='12px ui-monospace,monospace';
    cg.textAlign='center';
    for(const p of [{
      x:800,y:518
    }
    ,{
      x:755,y:430
    }
    ,{
      x:1460,y:740
    }
    ,{
      x:420,y:245
    }
    ,{
      x:550,y:1010
    }
    ]){
      const z=Math.round(C.heightAt(p.x,p.y)/10)*10;
      cg.fillStyle='#4b624d';
      cg.fillText(z+'',p.x,p.y)
    }
  }
  renderTerrain();
  function fitCamera(){
    const rect=canvas.getBoundingClientRect();
    camera.w=rect.width;
    camera.h=rect.height;
    camera.zoom=Math.min(camera.w/C.WORLD.w,camera.h/C.WORLD.h)*.94;
    camera.x=900;
    camera.y=625;
    clampCamera()
  }
  function resize(initial=false){
    const r=canvas.getBoundingClientRect();
    camera.w=r.width;
    camera.h=r.height;
    camera.dpr=Math.min(devicePixelRatio||1,2);
    canvas.width=Math.round(r.width*camera.dpr);
    canvas.height=Math.round(r.height*camera.dpr);
    if(initial||!camera.zoom)fitCamera();
    else clampCamera()
  }
  function clampCamera(){
    const margin=100,cx=camera.w/(2*camera.zoom),cy=camera.h/(2*camera.zoom);
    camera.x=cx>950?900:C.clamp(camera.x,cx-margin,1800-cx+margin);
    camera.y=cy>675?625:C.clamp(camera.y,cy-margin,1250-cy+margin)
  }
  function toWorld(x,y){
    return {
      x:(x-camera.w/2)/camera.zoom+camera.x,y:(y-camera.h/2)/camera.zoom+camera.y
    }
  }
  function toScreen(x,y){
    return {
      x:(x-camera.x)*camera.zoom+camera.w/2,y:(y-camera.y)*camera.zoom+camera.h/2
    }
  }
  function zoomAt(factor,sx=camera.w/2,sy=camera.h/2){
    const p=toWorld(sx,sy),min=Math.min(camera.w/1800,camera.h/1250)*.65;
    camera.zoom=C.clamp(camera.zoom*factor,min,4);
    camera.x=p.x-(sx-camera.w/2)/camera.zoom;
    camera.y=p.y-(sy-camera.h/2)/camera.zoom;
    clampCamera()
  }
  function toast(text){
    $('toast').textContent=text;
    $('toast').classList.add('show');
    toastUntil=performance.now()+2700
  }
  function setReverse(v){
    reverseMode=v;
    $('reverse').classList.toggle('active',v);
    $('reverse').setAttribute('aria-pressed',v);
    $('move').classList.toggle('active',!v);
    $('move').setAttribute('aria-pressed',!v)
  }
  function select(id){
    selected=id;
    targetId=null;
    visibilityDirty=true;
    updateUI();
  }
  function moveTo(p){
    const u=selectedUnit();
    if(!u)return;
    const r=C.issueMove(u,p,reverseMode,sim.units);
    if(!r.ok){
      toast(r.reason);
      return
    }
    toast((reverseMode?'후진':'이동')+' 경로 지정 · '+Math.round(C.routeDistance(u))+'m');
    updateUI()
  }
  function setSight(v){
    sightHeld=!!v;
    wrap.classList.toggle('sight-on',sightHeld);
    $('sight').classList.toggle('holding',sightHeld);
    $('sight').setAttribute('aria-pressed',sightHeld);
    if(v)visibilityDirty=true
  }
  function releaseSight(){
    sightPointer=null;
    sightKey=false;
    setSight(false)
  }
  const sightButton=$('sight');
  sightButton.addEventListener('pointerdown',e=>{
    e.preventDefault();
    sightPointer=e.pointerId;
    sightButton.setPointerCapture(e.pointerId);
    setSight(true)
  }
  );
  for(const type of ['pointerup','pointercancel','lostpointercapture'])sightButton.addEventListener(type,e=>{
    if(sightPointer===e.pointerId){
      sightPointer=null;
      setSight(sightKey)
    }
  }
  );
  sightButton.addEventListener('contextmenu',e=>e.preventDefault());
  sightButton.addEventListener('keydown',e=>{
    if(e.code==='Space'||e.code==='Enter'){
      e.preventDefault();
      sightKey=true;
      setSight(true)
    }
  }
  );
  sightButton.addEventListener('keyup',e=>{
    if(e.code==='Space'||e.code==='Enter'){
      sightKey=false;
      setSight(sightPointer!==null)
    }
  }
  );
  function canTeamSee(t){
    return sim.units.some(u=>u.team==='blue'&&C.exposure(u,t).visible)
  }
  function tap(sx,sy){
    const p=toWorld(sx,sy);
    let best=null,bd=24;
    for(const u of sim.units){
      if(u.team==='red'&&!canTeamSee(u))continue;
      const q=toScreen(u.x,u.y),d=Math.hypot(q.x-sx,q.y-sy);
      if(d<bd){
        bd=d;
        best=u
      }
    }
    if(best){
      if(best.team==='blue')select(best.id);
      else{
        targetId=best.id;
        const ex=C.exposure(selectedUnit(),best);
        toast(best.name+' · 차체 '+Math.round(ex.hull*100)+'% / 포탑 '+Math.round(ex.turret*100)+'% 노출');
        updateUI()
      }
      return
    }
    if(p.x>=0&&p.y>=0&&p.x<=1800&&p.y<=1250)moveTo(p)
  }
  function localPoint(e){
    const r=canvas.getBoundingClientRect();
    return {
      x:e.clientX-r.left,y:e.clientY-r.top
    }
  }
  canvas.addEventListener('pointerdown',e=>{
    if(e.button!==0&&e.pointerType==='mouse')return;
    e.preventDefault();
    canvas.setPointerCapture(e.pointerId);
    const p=localPoint(e);
    pointers.set(e.pointerId,p);
    if(pointers.size===1){
      clickStart={
        ...p,id:e.pointerId,cx:camera.x,cy:camera.y
      }
      ;
      dragged=false;
      gesture=null
    }
    else if(pointers.size===2){
      dragged=true;
      const a=[...pointers.values()];
      gesture={
        distance:Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y),mid:{
          x:(a[0].x+a[1].x)/2,y:(a[0].y+a[1].y)/2
        }
      }
    }
  }
  );
  canvas.addEventListener('pointermove',e=>{
    const p=localPoint(e),world=toWorld(p.x,p.y);
    $('coords').textContent='X '+Math.round(world.x)+' · Y '+Math.round(world.y);
    if(!pointers.has(e.pointerId))return;
    e.preventDefault();
    pointers.set(e.pointerId,p);
    if(pointers.size===2&&gesture){
      const a=[...pointers.values()],d=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y),mid={
        x:(a[0].x+a[1].x)/2,y:(a[0].y+a[1].y)/2
      }
      ;
      if(d>5&&gesture.distance>5)zoomAt(d/gesture.distance,gesture.mid.x,gesture.mid.y);
      camera.x-=(mid.x-gesture.mid.x)/camera.zoom;
      camera.y-=(mid.y-gesture.mid.y)/camera.zoom;
      clampCamera();
      gesture={
        distance:d,mid
      }
    }
    else if(pointers.size===1&&clickStart){
      const dx=p.x-clickStart.x,dy=p.y-clickStart.y;
      if(Math.hypot(dx,dy)>7)dragged=true;
      if(dragged){
        camera.x=clickStart.cx-dx/camera.zoom;
        camera.y=clickStart.cy-dy/camera.zoom;
        clampCamera()
      }
    }
  }
  );
  function endPointer(e){
    if(!pointers.has(e.pointerId))return;
    const p=localPoint(e),wasOnly=pointers.size===1;
    if(e.type==='pointerup'&&wasOnly&&!dragged&&clickStart)tap(p.x,p.y);
    pointers.delete(e.pointerId);
    gesture=null;
    clickStart=null;
    if(pointers.size)dragged=true
  }
  for(const type of ['pointerup','pointercancel','lostpointercapture'])canvas.addEventListener(type,endPointer);
  canvas.addEventListener('wheel',e=>{
    e.preventDefault();
    const p=localPoint(e);
    zoomAt(Math.exp(-e.deltaY*.0015),p.x,p.y)
  }
  ,{
    passive:false
  }
  );
  canvas.addEventListener('contextmenu',e=>e.preventDefault());
  $('move').onclick=()=>{
    setReverse(false);
    toast('이동할 지면을 탭해줘')
  }
  ;
  $('reverse').onclick=()=>{
    setReverse(!reverseMode);
    toast(reverseMode?'후진할 지면을 탭해줘':'전진 이동 모드')
  }
  ;
  $('stop').onclick=()=>{
    C.stop(selectedUnit());
    toast('정지 명령');
    updateUI()
  }
  ;
  $('zoomIn').onclick=()=>zoomAt(1.35);
  $('zoomOut').onclick=()=>zoomAt(1/1.35);
  $('fit').onclick=()=>fitCamera();
  $('contours').onclick=()=>{
    showContours=!showContours;
    $('contours').classList.toggle('active',showContours);
    $('contours').setAttribute('aria-pressed',showContours)
  }
  ;
  function setPaused(v){
    paused=v;
    $('app').classList.toggle('paused',v);
    $('pause').textContent=v?'▶':'Ⅱ';
    $('pause').setAttribute('aria-label',v?'재생':'일시정지');
    $('pause').classList.toggle('active',v);
    accumulator=0
  }
  $('pause').onclick=()=>setPaused(!paused);
  $('speed').onclick=()=>{
    timeScale=timeScale===1?2:1;
    $('speed').textContent=timeScale+'×'
  }
  ;
  async function toggleFullscreen(){
    try{
      if(document.fullscreenElement){
        await document.exitFullscreen();
        return
      }
      if(document.documentElement.requestFullscreen){
        await document.documentElement.requestFullscreen();
        try{
          await screen.orientation?.lock?.('landscape')
        }
        catch{
        }
        return
      }
      throw Error('unsupported')
    }
    catch{
      const app=$('app');
      app.classList.toggle('focus-mode');
      toast(app.classList.contains('focus-mode')?'브라우저 전체화면 대신 지도 집중 모드로 전환함':'지도 집중 모드 해제');
      setTimeout(()=>resize(),80)
    }
  }
  $('fullscreen').onclick=toggleFullscreen;
  document.addEventListener('fullscreenchange',()=>{
    releaseSight();
    $('fullscreen').classList.toggle('active',!!document.fullscreenElement);
    setTimeout(()=>resize(),80)
  }
  );
  $('reset').onclick=()=>{
    sim=C.createScenario();
    selected='A11';
    targetId=null;
    trails.length=0;
    setPaused(false);
    setReverse(false);
    releaseSight();
    timeScale=1;
    $('speed').textContent='1×';
    visibilityDirty=true;
    fitCamera();
    updateUI();
    toast('시험장을 초기 상태로 되돌렸음')
  }
  ;
  window.addEventListener('keydown',e=>{
    if(e.target instanceof HTMLButtonElement&&['Space','Enter'].includes(e.code))return;
    if(e.code==='KeyV'){
      e.preventDefault();
      sightKey=true;
      setSight(true)
    }
    else if(!e.repeat){
      if(e.code==='Space'){
        e.preventDefault();
        setPaused(!paused)
      }
      if(e.code==='KeyR')setReverse(!reverseMode);
      if(e.code==='KeyX')C.stop(selectedUnit());
      if(e.code==='KeyF')toggleFullscreen();
      if(e.code==='Home')fitCamera()
    }
  }
  );
  window.addEventListener('keyup',e=>{
    if(e.code==='KeyV'){
      sightKey=false;
      setSight(sightPointer!==null)
    }
  }
  );
  window.addEventListener('blur',()=>{
    releaseSight();
    pointers.clear();
    clickStart=null;
    gesture=null;
    accumulator=0;
    last=performance.now()
  }
  );
  document.addEventListener('visibilitychange',()=>{
    releaseSight();
    pointers.clear();
    clickStart=null;
    gesture=null;
    accumulator=0;
    last=performance.now()
  }
  );
  window.addEventListener('resize',()=>resize());
  new ResizeObserver(()=>resize()).observe(wrap);
  function updateVisibility(now){
    const u=selectedUnit();
    if(!sightHeld||!u)return;
    if(!visibilityDirty&&now-visLast<350)return;
    if(!visibilityDirty&&visOrigin&&Math.hypot(u.x-visOrigin.x,u.y-visOrigin.y)<3)return;
    const cell=20,w=Math.ceil(1800/cell),h=Math.ceil(1250/cell);
    visCanvas.width=w;
    visCanvas.height=h;
    const g=visCanvas.getContext('2d'),img=g.createImageData(w,h);
    for(let y=0;
    y<h;
    y++)for(let x=0;
    x<w;
    x++){
      const p={
        x:(x+.5)*cell,y:(y+.5)*cell
      }
      ,d=Math.hypot(p.x-u.x,p.y-u.y),k=(y*w+x)*4;
      if(d>C.VEHICLE.range){
        img.data[k]=9;
        img.data[k+1]=22;
        img.data[k+2]=19;
        img.data[k+3]=140
      }
      else if(C.lineOfSight(u,p,1.5).visible){
        img.data[k]=78;
        img.data[k+1]=215;
        img.data[k+2]=170;
        img.data[k+3]=81
      }
      else{
        img.data[k]=91;
        img.data[k+1]=41;
        img.data[k+2]=30;
        img.data[k+3]=153
      }
    }
    g.putImageData(img,0,0);
    visLast=now;
    visOrigin={
      x:u.x,y:u.y
    }
    ;
    visibilityDirty=false
  }
  function updateUI(){
    const u=selectedUnit();
    $('unitName').textContent=u.name;
    $('velocity').textContent=Math.round(u.speed*3.6);
    $('motionState').textContent=u.state;
    $('elevation').textContent=C.heightAt(u.x,u.y).toFixed(1)+' m';
    $('slope').textContent=(Math.atan(C.slopeAt(u.x,u.y))*180/Math.PI).toFixed(1)+'°';
    $('heading').textContent=((Math.round(u.heading*180/Math.PI)+90)%360+360)%360+'°';
    $('surface').textContent=({
      grass:'초지',road:'도로',forest:'숲',bridge:'교량',water:'하천',obstacle:'장애물'
    }
    )[C.surfaceAt(u.x,u.y)];
    const dist=C.routeDistance(u);
    $('routeInfo').innerHTML=u.path.length?'<strong>'+(u.reverse?'후진':'이동')+' 경로</strong> · 남은 거리 '+Math.round(dist)+'m':'지면을 탭해서 <strong>이동 경로</strong>를 지정해봐.';
    $('clock').textContent='T+ '+String(Math.floor(sim.time/60)).padStart(2,'0')+':'+String(Math.floor(sim.time%60)).padStart(2,'0');
    $('simState').textContent=paused?'일시정지':'기동 시험';
    for(const b of $('roster').children){
      const v=sim.units.find(v=>v.id===b.dataset.id);
      b.classList.toggle('active',v.id===selected);
      b.querySelector('.unit-sub').textContent=v.state+' · '+Math.round(v.speed*3.6)+' km/h';
      b.setAttribute('aria-pressed',v.id===selected)
    }
    const target=sim.units.find(v=>v.id===targetId);
    $('targetPanel').classList.toggle('visible',!!target);
    if(target){
      const ex=C.exposure(u,target);
      $('targetTitle').textContent=target.name;
      for(const part of ['hull','turret']){
        $(part+'Bar').style.width=Math.round(ex[part]*100)+'%';
        $(part+'Value').textContent=Math.round(ex[part]*100)+'%'
      }
    }
  }
  for(const u of sim.units.filter(u=>u.team==='blue')){
    const b=document.createElement('button');
    b.className='unit-card';
    b.dataset.id=u.id;
    b.innerHTML='<span class="unit-symbol"><span></span></span><span><span class="unit-title">'+u.name+'</span><div class="unit-sub">대기 · 0 km/h</div></span><span class="unit-status"></span>';
    b.onclick=()=>{
      select(u.id);
      camera.x=u.x;
      camera.y=u.y;
      camera.zoom=Math.max(camera.zoom,.8);
      clampCamera()
    }
    ;
    $('roster').appendChild(b)
  }
  function drawTank(u){
    const p=toScreen(u.x,u.y),isSelected=u.id===selected,enemy=u.team==='red',size=C.clamp(camera.zoom*10,11,30),hullColor=enemy?'#b17a4f':isSelected?'#657b48':'#536f4e',edge=enemy?'#efc28d':'#d8e4b9';
    ctx.save();
    ctx.translate(p.x,p.y);
    if(isSelected){
      ctx.strokeStyle='#cce9a3';
      ctx.lineWidth=1.5;
      ctx.setLineDash([4,3]);
      ctx.beginPath();
      ctx.arc(0,0,size+9,0,Math.PI*2);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle='#d9edb6';
      ctx.beginPath();
      ctx.moveTo(0,-size-16);
      ctx.lineTo(-4,-size-22);
      ctx.lineTo(4,-size-22);
      ctx.closePath();
      ctx.fill()
    }
    if(u.id===targetId){
      ctx.strokeStyle='#ffd19b';
      ctx.lineWidth=1.5;
      ctx.strokeRect(-size-6,-size-6,size*2+12,size*2+12)
    }
    ctx.save();
    ctx.rotate(u.heading);
    ctx.fillStyle='#192d2399';
    ctx.fillRect(-size*.8+2,-size*.6+3,size*1.6,size*1.2);
    ctx.fillStyle='#26382a';
    ctx.fillRect(-size*.85,-size*.65,size*1.7,size*.29);
    ctx.fillRect(-size*.85,size*.36,size*1.7,size*.29);
    ctx.fillStyle=hullColor;
    ctx.strokeStyle=edge;
    ctx.lineWidth=.8;
    ctx.beginPath();
    ctx.moveTo(-size*.8,-size*.39);
    ctx.lineTo(size*.62,-size*.39);
    ctx.lineTo(size*.86,-size*.24);
    ctx.lineTo(size*.86,size*.24);
    ctx.lineTo(size*.62,size*.39);
    ctx.lineTo(-size*.8,size*.39);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle='#c3cd9b55';
    for(let x=-size*.65;
    x<size*.4;
    x+=size*.3){
      ctx.beginPath();
      ctx.moveTo(x,-size*.62);
      ctx.lineTo(x,-size*.4);
      ctx.moveTo(x,size*.4);
      ctx.lineTo(x,size*.62);
      ctx.stroke()
    }
    ctx.restore();
    ctx.save();
    ctx.rotate(u.turret);
    ctx.strokeStyle=edge;
    ctx.lineWidth=2;
    ctx.beginPath();
    ctx.moveTo(size*.2,0);
    ctx.lineTo(size*1.5,0);
    ctx.stroke();
    ctx.fillStyle=enemy?'#c38c59':'#7c9456';
    ctx.strokeStyle=edge;
    ctx.lineWidth=.7;
    ctx.beginPath();
    ctx.ellipse(0,0,size*.49,size*.32,0,0,Math.PI*2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle='#30492d';
    ctx.beginPath();
    ctx.arc(-size*.1,-size*.06,size*.12,0,Math.PI*2);
    ctx.fill();
    ctx.restore();
    ctx.font='600 10px ui-monospace,monospace';
    ctx.textAlign='center';
    const text=enemy?u.id:u.name;
    ctx.fillStyle='#12271fe8';
    const tw=ctx.measureText(text).width;
    ctx.fillRect(-tw/2-5,size+11,tw+10,17);
    ctx.fillStyle=enemy?'#f0bd86':'#e3edcc';
    ctx.fillText(text,0,size+23);
    ctx.restore()
  }
  function drawRoute(u){
    if(!u.path.length)return;
    const selectedRoute=u.id===selected;
    ctx.save();
    ctx.strokeStyle=selectedRoute?'#e8eead':'#c0d5b780';
    ctx.lineWidth=selectedRoute?2:1;
    ctx.setLineDash(u.reverse?[3,5]:[8,5]);
    ctx.beginPath();
    let p=toScreen(u.x,u.y);
    ctx.moveTo(p.x,p.y);
    for(const q of u.path){
      p=toScreen(q.x,q.y);
      ctx.lineTo(p.x,p.y)
    }
    ctx.stroke();
    ctx.setLineDash([]);
    if(u.goal){
      p=toScreen(u.goal.x,u.goal.y);
      ctx.strokeStyle='#293e2a';
      ctx.lineWidth=4;
      ctx.beginPath();
      ctx.arc(p.x,p.y,7,0,Math.PI*2);
      ctx.stroke();
      ctx.strokeStyle='#e8eead';
      ctx.lineWidth=1.5;
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(p.x-11,p.y);
      ctx.lineTo(p.x+11,p.y);
      ctx.moveTo(p.x,p.y-11);
      ctx.lineTo(p.x,p.y+11);
      ctx.stroke()
    }
    ctx.restore()
  }
  function label(text,x,y,size=12){
    const p=toScreen(x,y);
    ctx.font='500 '+size+'px system-ui,sans-serif';
    ctx.textAlign='center';
    ctx.fillStyle='#d8ddbb';
    ctx.strokeStyle='#d8ddbb99';
    ctx.lineWidth=4;
    ctx.strokeText(text,p.x,p.y);
    ctx.fillStyle='#40543b';
    ctx.fillText(text,p.x,p.y)
  }
  function draw(now){
    frameCount++;
    updateVisibility(now);
    ctx.setTransform(camera.dpr,0,0,camera.dpr,0,0);
    ctx.clearRect(0,0,camera.w,camera.h);
    ctx.fillStyle='#899275';
    ctx.fillRect(0,0,camera.w,camera.h);
    const p=toScreen(0,0),ww=1800*camera.zoom,hh=1250*camera.zoom;
    ctx.drawImage(terrainCanvas,p.x,p.y,ww,hh);
    if(showContours)ctx.drawImage(contourCanvas,p.x,p.y,ww,hh);
    ctx.save();
    ctx.beginPath();
    ctx.rect(p.x,p.y,ww,hh);
    ctx.clip();
    if(camera.zoom>.65){
      for(const t of trails){
        const a=toScreen(t.x,t.y);
        ctx.save();
        ctx.translate(a.x,a.y);
        ctx.rotate(t.heading);
        ctx.fillStyle='#253b2940';
        ctx.fillRect(-2,-3.5,4,1.3);
        ctx.fillRect(-2,2.2,4,1.3);
        ctx.restore()
      }
    }
    if(sightHeld){
      ctx.imageSmoothingEnabled=false;
      ctx.drawImage(visCanvas,p.x,p.y,ww,hh);
      ctx.imageSmoothingEnabled=true;
      const u=selectedUnit(),q=toScreen(u.x,u.y);
      ctx.strokeStyle='#c1f1cc9e';
      ctx.lineWidth=1;
      ctx.setLineDash([7,5]);
      ctx.beginPath();
      ctx.arc(q.x,q.y,C.VEHICLE.range*camera.zoom,0,Math.PI*2);
      ctx.stroke();
      ctx.setLineDash([])
    }
    ctx.strokeStyle='#3e563c40';
    ctx.lineWidth=1;
    for(let x=0;
    x<=1800;
    x+=200){
      const q=toScreen(x,0);
      ctx.beginPath();
      ctx.moveTo(q.x,p.y);
      ctx.lineTo(q.x,p.y+hh);
      ctx.stroke()
    }
    for(let y=0;
    y<=1250;
    y+=200){
      const q=toScreen(0,y);
      ctx.beginPath();
      ctx.moveTo(p.x,q.y);
      ctx.lineTo(p.x+ww,q.y);
      ctx.stroke()
    }
    ctx.restore();
    if(!sightHeld){
      label('서부 수림',480,410,11);
      label('중앙 능선',790,655,11);
      label('동부 취락',1390,180,11);
      label('남부 교량',1110,992,10);
      label('출발 지점',310,1130,10)
    }
    for(const u of sim.units)if(u.team==='blue')drawRoute(u);
    for(const u of sim.units)if(u.team==='blue'||canTeamSee(u))drawTank(u);
    ctx.strokeStyle='#e3e6c155';
    ctx.lineWidth=1;
    ctx.strokeRect(p.x,p.y,ww,hh);
    const scale=100*camera.zoom<55?200:100;
    $('scaleLine').style.width=scale*camera.zoom+'px';
    $('scaleText').textContent=scale+' m';
    if(now>toastUntil)$('toast').classList.remove('show')
  }
  function loop(now){
    const elapsed=Math.min(.12,(now-last)/1000);
    last=now;
    if(!paused&&!document.hidden){
      accumulator+=elapsed*timeScale;
      let steps=0;
      while(accumulator>=.05&&steps<6){
        C.step(sim,.05);
        accumulator-=.05;
        steps++;
        for(const u of sim.units){
          u.trackTimer+=.05;
          if(u.team==='blue'&&u.speed>1&&u.trackTimer>.55){
            trails.push({
              x:u.x,y:u.y,heading:u.heading
            }
            );
            u.trackTimer=0;
            if(trails.length>1200)trails.shift()
          }
        }
      }
    }
    uiTime+=elapsed;
    if(uiTime>.15){
      updateUI();
      uiTime=0
    }
    draw(now);
    requestAnimationFrame(loop)
  }
  resize(true);
  updateUI();
  requestAnimationFrame(loop);
  // Read-only snapshot plus explicit commands for deterministic development checks.
  window.__TACTICAL__={
    version:'0.4-WIP01',core:C,snapshot:()=>JSON.parse(JSON.stringify({
      time:sim.time,selected,targetId,paused,timeScale,sightHeld,reverseMode,camera,units:sim.units,frameCount
    }
    )),command:(x,y,reverse=false)=>{
      setReverse(reverse);
      return C.issueMove(selectedUnit(),{
        x,y
      }
      ,reverse,sim.units)
    }
    ,select,exposure:(id)=>C.exposure(selectedUnit(),sim.units.find(u=>u.id===id)),worldToScreen:toScreen
  }
  ;
}
)();
