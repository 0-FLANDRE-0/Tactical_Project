'use strict';
/* Core contract: metres, seconds, radians; simulation never reads Canvas or UI.
Terrain -> navigation / movement / observation share one height field.
Rendering, decoration and pointer events never consume simulation randomness. */
const TacticalCore = (() => {
  const WORLD={
    w:1800,h:1250,step:10,nav:15
  }
  , VEHICLE={
    radius:5.2,maxSlope:.48,eye:2.6,range:850
  }
  ;
  const clamp=(x,a,b)=>Math.max(a,Math.min(b,x)),mix=(a,b,t)=>a+(b-a)*t;
  const angleDiff=(a,b)=>Math.atan2(Math.sin(a-b),Math.cos(a-b));
  const hash=(x,y,s=0)=>{
    let n=Math.imul(x+374761393,668265263)^Math.imul(y+1274126177,2246822519)^s;
    n=Math.imul(n^(n>>>13),1274126177);
    return ((n^(n>>>16))>>>0)/4294967296
  }
  ;
  const roads=[[{
    x:155,y:1050
  }
  ,{
    x:470,y:940
  }
  ,{
    x:650,y:780
  }
  ,{
    x:860,y:610
  }
  ,{
    x:1030,y:410
  }
  ,{
    x:1200,y:410
  }
  ,{
    x:1445,y:290
  }
  ,{
    x:1660,y:290
  }
  ],[{
    x:160,y:940
  }
  ,{
    x:1640,y:940
  }
  ]];
  const forests=[{
    x:430,y:410,rx:225,ry:170
  }
  ,{
    x:665,y:485,rx:135,ry:145
  }
  ,{
    x:1420,y:710,rx:230,ry:185
  }
  ,{
    x:1530,y:1010,rx:150,ry:105
  }
  ,{
    x:350,y:1140,rx:190,ry:90
  }
  ,{
    x:1300,y:105,rx:140,ry:80
  }
  ];
  const buildings=[{
    x:1270,y:265,w:37,h:24,z:7
  }
  ,{
    x:1330,y:238,w:31,h:36,z:9
  }
  ,{
    x:1390,y:235,w:38,h:25,z:7
  }
  ,{
    x:1452,y:222,w:31,h:39,z:8
  }
  ,{
    x:1300,y:322,w:43,h:25,z:7
  }
  ,{
    x:1370,y:330,w:31,h:30,z:8
  }
  ,{
    x:1480,y:335,w:46,h:25,z:7
  }
  ,{
    x:1550,y:240,w:32,h:30,z:8
  }
  ,{
    x:750,y:1010,w:35,h:26,z:6
  }
  ];
  const rocks=[{
    x:790,y:820,r:25,z:8
  }
  ,{
    x:835,y:858,r:18,z:5
  }
  ,{
    x:850,y:240,r:21,z:7
  }
  ,{
    x:1195,y:780,r:24,z:7
  }
  ];
  const riverX=y=>1070+48*Math.sin(y/175)+19*Math.sin(y/77);
  function rawHeight(x,y){
    const g=(cx,cy,rx,ry,a)=>a*Math.exp(-(((x-cx)/rx)**2+((y-cy)/ry)**2));
    return 19+g(805,565,150,345,87)+g(420,230,300,220,35)+g(1480,780,245,200,56)+g(550,1030,170,180,20)+2.6*Math.sin(x/165)*Math.cos(y/155)-g(riverX(y),y,39,2000,5)
  }
  const nx=Math.ceil(WORLD.w/WORLD.step)+1,ny=Math.ceil(WORLD.h/WORLD.step)+1,heights=new Float32Array(nx*ny),forestGrid=new Float32Array(nx*ny);
  function rawForest(x,y){
    let best=0;
    for(const f of forests){
      const q=((x-f.x)/f.rx)**2+((y-f.y)/f.ry)**2;
      best=Math.max(best,clamp((1.12-q)*1.4,0,1))
    }
    return best
  }
  for(let j=0;
  j<ny;
  j++)for(let i=0;
  i<nx;
  i++){
    heights[j*nx+i]=rawHeight(i*10,j*10);
    forestGrid[j*nx+i]=rawForest(i*10,j*10)
  }
  function field(grid,x,y){
    const gx=clamp(x/10,0,nx-1.001),gy=clamp(y/10,0,ny-1.001),i=gx|0,j=gy|0,a=gx-i,b=gy-j,k=j*nx+i;
    return mix(mix(grid[k],grid[k+1],a),mix(grid[k+nx],grid[k+nx+1],a),b)
  }
  const heightAt=(x,y)=>field(heights,x,y),forestAt=(x,y)=>field(forestGrid,x,y);
  function slopeAt(x,y){
    return Math.hypot(heightAt(x+5,y)-heightAt(x-5,y),heightAt(x,y+5)-heightAt(x,y-5))/10
  }
  function distanceSegment(x,y,a,b){
    const dx=b.x-a.x,dy=b.y-a.y,t=clamp(((x-a.x)*dx+(y-a.y)*dy)/(dx*dx+dy*dy),0,1);
    return Math.hypot(x-a.x-dx*t,y-a.y-dy*t)
  }
  function roadDistance(x,y){
    let d=Infinity;
    for(const road of roads)for(let i=1;
    i<road.length;
    i++)d=Math.min(d,distanceSegment(x,y,road[i-1],road[i]));
    return d
  }
  const bridgeAt=(x,y)=>Math.abs(x-riverX(y))<58&&(Math.abs(y-940)<17||Math.abs(y-410)<17);
  const waterAt=(x,y)=>Math.abs(x-riverX(y))<19&&!bridgeAt(x,y);
  function buildingAt(x,y,pad=0){
    return buildings.find(b=>x>=b.x-pad&&x<=b.x+b.w+pad&&y>=b.y-pad&&y<=b.y+b.h+pad)
  }
  function solidAt(x,y,pad=0){
    return buildingAt(x,y,pad)||rocks.find(r=>Math.hypot(x-r.x,y-r.y)<r.r+pad)
  }
  function surfaceAt(x,y){
    if(waterAt(x,y))return 'water';
    if(bridgeAt(x,y))return 'bridge';
    if(solidAt(x,y))return 'obstacle';
    if(roadDistance(x,y)<12)return 'road';
    if(forestAt(x,y)>.18)return 'forest';
    return 'grass'
  }
  function passable(x,y,units=[],ignore=null){
    const r=VEHICLE.radius;
    if(x<r+2||y<r+2||x>WORLD.w-r-2||y>WORLD.h-r-2||solidAt(x,y,r)||slopeAt(x,y)>VEHICLE.maxSlope)return false;
    for(const [dx,dy]of [[0,0],[r,0],[-r,0],[0,r],[0,-r]])if(waterAt(x+dx,y+dy))return false;
    for(const u of units)if(u!==ignore&&Math.hypot(u.x-x,u.y-y)<r*2.1)return false;
    return true
  }
  function segmentClear(a,b,units=[],ignore=null){
    const d=Math.hypot(a.x-b.x,a.y-b.y),n=Math.max(1,Math.ceil(d/4));
    for(let i=0;
    i<=n;
    i++){
      const t=i/n;
      if(!passable(mix(a.x,b.x,t),mix(a.y,b.y,t),units,ignore))return false
    }
    return true
  }
  function travelCost(x,y){
    const road=roadDistance(x,y)<12,forest=forestAt(x,y);
    return (road?.56:1+forest*1.65)*(1+slopeAt(x,y)*3)
  }
  const cols=Math.ceil(WORLD.w/15),rows=Math.ceil(WORLD.h/15),navCost=new Float32Array(cols*rows);
  const cellPoint=id=>({
    x:(id%cols+.5)*15,y:(Math.floor(id/cols)+.5)*15
  }
  );
  for(let id=0;
  id<navCost.length;
  id++){
    const p=cellPoint(id);
    navCost[id]=passable(p.x,p.y)?travelCost(p.x,p.y):Infinity
  }
  class Heap{
    constructor(){
      this.a=[]
    }
    push(id,f){
      const v={
        id,f
      }
      ,a=this.a;
      let i=a.length;
      a.push(v);
      while(i){
        const p=(i-1)>>1;
        if(a[p].f<=f)break;
        a[i]=a[p];
        i=p
      }
      a[i]=v
    }
    pop(){
      const a=this.a,v=a[0],last=a.pop();
      if(a.length){
        let i=0;
        while(i*2+1<a.length){
          let c=i*2+1;
          if(c+1<a.length&&a[c+1].f<a[c].f)c++;
          if(a[c].f>=last.f)break;
          a[i]=a[c];
          i=c
        }
        a[i]=last
      }
      return v
    }
    get length(){
      return this.a.length
    }
  }
  function cellFor(p){
    return clamp(Math.floor(p.y/15),0,rows-1)*cols+clamp(Math.floor(p.x/15),0,cols-1)
  }
  function nearestCell(p,units,ignore){
    const cx=Math.floor(p.x/15),cy=Math.floor(p.y/15);
    let best=-1,bd=Infinity;
    for(let y=cy-2;
    y<=cy+2;
    y++)for(let x=cx-2;
    x<=cx+2;
    x++){
      if(x<0||y<0||x>=cols||y>=rows)continue;
      const id=y*cols+x,q=cellPoint(id),d=Math.hypot(q.x-p.x,q.y-p.y);
      if(d<bd&&Number.isFinite(navCost[id])&&segmentClear(p,q,units,ignore)){
        best=id;
        bd=d
      }
    }
    return best
  }
  function segmentCost(a,b){
    const d=Math.hypot(a.x-b.x,a.y-b.y),n=Math.max(1,Math.ceil(d/12));
    let cost=0;
    for(let i=0;
    i<n;
    i++){
      const t=(i+.5)/n;
      cost+=travelCost(mix(a.x,b.x,t),mix(a.y,b.y,t))*d/n
    }
    return cost
  }
  function planPath(start,goal,units=[],ignore=null){
    if(!passable(goal.x,goal.y,units,ignore))return {
      ok:false,reason:'이 지점은 전차가 통과할 수 없음',points:[]
    }
    ;
    const s=nearestCell(start,units,ignore),g=nearestCell(goal,units,ignore);
    if(s<0||g<0)return {
      ok:false,reason:'연결 가능한 경로가 없음',points:[]
    }
    ;
    const n=navCost.length,dist=new Float64Array(n),prev=new Int32Array(n),closed=new Uint8Array(n),heap=new Heap();
    dist.fill(Infinity);
    prev.fill(-1);
    dist[s]=0;
    const gp=cellPoint(g),heuristic=id=>{
      const p=cellPoint(id);
      return Math.hypot(p.x-gp.x,p.y-gp.y)*.56
    }
    ;
    heap.push(s,heuristic(s));
    let visits=0;
    while(heap.length&&visits<n){
      const id=heap.pop().id;
      if(closed[id])continue;
      closed[id]=1;
      visits++;
      if(id===g)break;
      const x=id%cols,y=Math.floor(id/cols),p=cellPoint(id);
      for(const [dx,dy]of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]){
        const xx=x+dx,yy=y+dy;
        if(xx<0||yy<0||xx>=cols||yy>=rows)continue;
        const ni=yy*cols+xx;
        if(closed[ni]||!Number.isFinite(navCost[ni]))continue;
        if(dx&&dy&&(!Number.isFinite(navCost[y*cols+xx])||!Number.isFinite(navCost[yy*cols+x])))continue;
        const q=cellPoint(ni);
        if(!segmentClear(p,q,units,ignore))continue;
        const nd=dist[id]+Math.hypot(dx,dy)*15*(navCost[id]+navCost[ni])*.5;
        if(nd<dist[ni]){
          dist[ni]=nd;
          prev[ni]=id;
          heap.push(ni,nd+heuristic(ni))
        }
      }
    }
    if(!Number.isFinite(dist[g]))return {
      ok:false,reason:'지형을 우회할 경로가 없음',points:[]
    }
    ;
    let raw=[];
    for(let id=g;
    id!==-1;
    id=prev[id]){
      raw.push(cellPoint(id));
      if(id===s)break
    }
    raw.reverse();
    raw.unshift({
      x:start.x,y:start.y
    }
    );
    raw.push({
      x:goal.x,y:goal.y
    }
    );
    const points=[raw[0]];
    let a=0;
    while(a<raw.length-1){
      let best=a+1,routed=0;
      for(let j=a+1;
      j<raw.length&&j<a+28;
      j++){
        routed+=segmentCost(raw[j-1],raw[j]);
        if(segmentClear(raw[a],raw[j],units,ignore)&&segmentCost(raw[a],raw[j])<=routed*1.12)best=j
      }
      points.push(raw[best]);
      a=best
    }
    return {
      ok:true,points:points.slice(1),visits,cost:dist[g]
    }
  }
  function makeTank(id,name,x,y,heading,team='blue'){
    return {
      id,name,x,y,heading,turret:heading,speed:0,path:[],goal:null,reverse:false,team,state:'대기',distanceTravelled:0,blockedFor:0,replanTimer:0,trackTimer:0
    }
  }
  function createScenario(){
    return {
      time:0,units:[makeTank('A11','ALPHA 11',300,990,-.65),makeTank('A12','ALPHA 12',350,1050,-.65),makeTank('T01','관측 표적 01',935,490,2.2,'red'),makeTank('T02','관측 표적 02',1350,445,2.9,'red'),makeTank('T03','관측 표적 03',580,820,2.1,'red')]
    }
  }
  function issueMove(u,goal,reverse,units){
    const r=planPath(u,goal,units,u);
    if(!r.ok)return r;
    u.path=r.points;
    u.goal={
      ...goal
    }
    ;
    u.reverse=reverse;
    u.state=reverse?'후진 이동':'이동';
    u.blockedFor=0;
    return r
  }
  function stop(u){
    u.path=[];
    u.goal=null;
    u.state=u.speed>.15?'감속':'대기'
  }
  function routeDistance(u){
    let d=0,p=u;
    for(const q of u.path){
      d+=Math.hypot(q.x-p.x,q.y-p.y);
      p=q
    }
    return d
  }
  function stepTank(u,dt,units){
    if(u.team!=='blue')return;
    u.replanTimer=Math.max(0,u.replanTimer-dt);
    while(u.path.length>1&&Math.hypot(u.path[0].x-u.x,u.path[0].y-u.y)<8)u.path.shift();
    let desired=0,err=0;
    if(u.path.length){
      const p=u.path[0],d=Math.hypot(p.x-u.x,p.y-u.y);
      if(u.path.length===1&&d<2.5){
        u.path=[];
        u.goal=null;
        u.state='대기';
        u.speed=0;
        return
      }
      const aim=Math.atan2(p.y-u.y,p.x-u.x)+(u.reverse?Math.PI:0);
      err=angleDiff(aim,u.heading);
      const turnLimit=(u.speed<1?.85:.65/(1+u.speed*.10))*dt;
      u.heading+=clamp(err,-turnLimit,turnLimit);
      const surface=surfaceAt(u.x,u.y),base=u.reverse?4.5:(surface==='road'||surface==='bridge'?15:surface==='forest'?6.5:10.5),slope=slopeAt(u.x,u.y),corner=Math.max(0,Math.cos(err));
      desired=Math.min(base*(1-clamp(slope*.9,0,.6))*corner*corner,Math.sqrt(Math.max(0,2*2.2*(routeDistance(u)-1))));
      if(Math.abs(err)>1.15)desired=0;
      u.state=desired<.2?'선회':u.reverse?'후진 이동':'이동'
    }
    else if(u.speed>.1)u.state='감속';
    else u.state='대기';
    u.speed+=clamp(desired-u.speed,-3*dt,1.8*dt);
    if(u.speed<.025)u.speed=0;
    const sign=u.reverse?-1:1,nx=u.x+Math.cos(u.heading)*u.speed*sign*dt,ny=u.y+Math.sin(u.heading)*u.speed*sign*dt;
    if(u.speed>0&&segmentClear(u,{
      x:nx,y:ny
    }
    ,units,u)){
      u.distanceTravelled+=u.speed*dt;
      u.x=nx;
      u.y=ny;
      u.blockedFor=0
    }
    else if(u.speed>0){
      u.speed=0;
      u.blockedFor+=dt;
      u.state='경로 대기';
      if(u.goal&&u.replanTimer<=0){
        const r=planPath(u,u.goal,units,u);
        if(r.ok)u.path=r.points;
        u.replanTimer=1.5
      }
    }
    u.turret+=clamp(angleDiff(u.heading,u.turret),-.65*dt,.65*dt)
  }
  function step(s,dt){
    s.time+=dt;
    for(const u of s.units)stepTank(u,dt,s.units)
  }
  function blockerTop(x,y){
    let z=heightAt(x,y);
    const b=buildingAt(x,y);
    if(b)z+=b.z;
    for(const r of rocks)if(Math.hypot(x-r.x,y-r.y)<r.r)z=Math.max(z,heightAt(x,y)+r.z);
    return z
  }
  function lineOfSight(observer,target,targetHeight=1.5){
    const d=Math.hypot(target.x-observer.x,target.y-observer.y);
    if(d>VEHICLE.range)return {
      visible:false,reason:'range',forestDepth:0
    }
    ;
    const start=heightAt(observer.x,observer.y)+VEHICLE.eye,end=heightAt(target.x,target.y)+targetHeight,n=Math.max(2,Math.ceil(d/6));
    let optical=0;
    for(let i=1;
    i<n;
    i++){
      const t=i/n,x=mix(observer.x,target.x,t),y=mix(observer.y,target.y,t),ray=mix(start,end,t),ground=heightAt(x,y);
      if(blockerTop(x,y)>ray+.06)return {
        visible:false,reason:'terrain',forestDepth:optical
      }
      ;
      if(ray<ground+15)optical+=forestAt(x,y)*d/n/85;
      if(optical>1)return {
        visible:false,reason:'forest',forestDepth:optical
      }
    }
    return {
      visible:true,reason:'clear',forestDepth:optical
    }
  }
  function exposure(observer,target){
    let hull=0,turret=0;
    const fx=Math.cos(target.heading),fy=Math.sin(target.heading);
    for(const along of [-2.8,0,2.8])for(const z of [.75,1.35])if(lineOfSight(observer,{
      x:target.x+fx*along,y:target.y+fy*along
    }
    ,z).visible)hull++;
    for(const along of [-1,0,1])if(lineOfSight(observer,{
      x:target.x+fx*along,y:target.y+fy*along
    }
    ,2.25).visible)turret++;
    return {
      hull:hull/6,turret:turret/3,visible:hull>0||turret>0
    }
  }
  return {
    WORLD,VEHICLE,roads,forests,buildings,rocks,clamp,mix,hash,angleDiff,heightAt,forestAt,slopeAt,roadDistance,riverX,bridgeAt,waterAt,surfaceAt,solidAt,passable,segmentClear,planPath,makeTank,createScenario,issueMove,stop,routeDistance,step,lineOfSight,exposure,rawHeight
  }
  ;
}
)();
if(typeof module!=='undefined')module.exports=TacticalCore;
